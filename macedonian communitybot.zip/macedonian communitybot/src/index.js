require("dotenv").config();

const { Client, GatewayIntentBits } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { loadCommands } = require("./handlers/commandHandler");
const { stopGuessScheduler } = require("./services/guessScheduler");

/** @type {import("discord.js").Client | null} */
let activeClient = null;
let shuttingDown = false;

async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`[CommunityBot] Shutting down (${signal})…`);
    stopGuessScheduler();
    if (activeClient) {
        try {
            await activeClient.destroy();
        } catch (err) {
            console.warn("[CommunityBot] Error while destroying client:", err.message);
        }
    }
    process.exit(0);
}

async function start() {
    if (!process.env.BOT_TOKEN) {
        console.error("[CommunityBot] BOT_TOKEN is missing. Copy .env.example to .env and set your token.");
        process.exit(1);
    }

    const client = new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent,
        ],
    });

    loadCommands(client);

    const eventsPath = path.join(__dirname, "events");
    if (fs.existsSync(eventsPath)) {
        const eventFiles = fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"));
        for (const file of eventFiles) {
            const event = require(path.join(eventsPath, file));
            if (event.once) {
                client.once(event.name, (...args) => event.execute(client, ...args));
            } else {
                client.on(event.name, (...args) => event.execute(client, ...args));
            }
            console.log(`[CommunityBot] Loaded event: ${event.name}`);
        }
    }

    process.on("unhandledRejection", (reason) => {
        console.error("[CommunityBot] Unhandled Rejection:", reason);
    });

    process.on("SIGINT", () => {
        shutdown("SIGINT").catch((err) => {
            console.error("[CommunityBot] Shutdown failed:", err.message);
            process.exit(1);
        });
    });
    process.on("SIGTERM", () => {
        shutdown("SIGTERM").catch((err) => {
            console.error("[CommunityBot] Shutdown failed:", err.message);
            process.exit(1);
        });
    });

    activeClient = client;
    await client.login(process.env.BOT_TOKEN);
}

start().catch((err) => {
    console.error("[CommunityBot] Failed to start:", err);
    process.exit(1);
});
