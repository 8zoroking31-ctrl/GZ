require("dotenv").config();

const { registerGuildCommands } = require("./services/registerCommands");

(async () => {
    try {
        const token = process.env.BOT_TOKEN;
        const clientId = process.env.CLIENT_ID;
        const guildId = process.env.GUILD_ID;

        if (!token || !clientId || !guildId) {
            console.error(
                "[CommunityBot] BOT_TOKEN, CLIENT_ID, and GUILD_ID are required in .env"
            );
            process.exit(1);
        }

        console.log(`[CommunityBot] Registering slash commands for guild ${guildId}…`);

        const count = await registerGuildCommands({
            token,
            clientId,
            guildId,
            clearGlobal: true,
        });

        console.log(`[CommunityBot] Registered ${count} guild commands (global commands cleared).`);
    } catch (error) {
        console.error("[CommunityBot] Failed to register commands:", error);
        process.exit(1);
    }
})();
