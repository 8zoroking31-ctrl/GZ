const { MessageFlags } = require("discord.js");

function componentsV2Payload(container, { ephemeral = false } = {}) {
    let flags = MessageFlags.IsComponentsV2;
    if (ephemeral) {
        flags |= MessageFlags.Ephemeral;
    }
    return {
        components: [container],
        flags,
    };
}

async function sendComponentsV2(target, container) {
    return target.send(componentsV2Payload(container));
}

async function replyEphemeral(interaction, containerOrText) {
    const container =
        typeof containerOrText === "string"
            ? require("./components").createNoticeContainer("Community bot", containerOrText)
            : containerOrText;

    const payload = componentsV2Payload(container, { ephemeral: true });

    if (interaction.deferred) {
        return interaction.editReply(payload);
    }
    if (interaction.replied) {
        return interaction.followUp(payload);
    }
    return interaction.reply(payload);
}

async function deferEphemeralV2(interaction) {
    if (!interaction.deferred && !interaction.replied) {
        await interaction.deferReply({ ephemeral: true });
    }
}

async function replyPublicV2(interaction, container) {
    const payload = componentsV2Payload(container, { ephemeral: false });

    if (interaction.deferred) {
        return interaction.editReply(payload);
    }
    if (interaction.replied) {
        return interaction.followUp(payload);
    }
    return interaction.reply(payload);
}

async function deferPublicV2(interaction) {
    if (!interaction.deferred && !interaction.replied) {
        await interaction.deferReply();
    }
}

module.exports = {
    componentsV2Payload,
    sendComponentsV2,
    replyEphemeral,
    replyPublicV2,
    deferPublicV2,
    deferEphemeralV2,
};
