const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const configPath = fs.existsSync(path.join(root, "config.js"))
    ? path.join(root, "config.js")
    : path.join(root, "config.example.js");

module.exports = require(configPath);
