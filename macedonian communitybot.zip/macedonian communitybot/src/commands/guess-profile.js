const { SlashCommandBuilder } = require("discord.js");
const { deferEphemeralV2, replyEphemeral } = require("../utils/replies");
const { createProfileContainer, createNoticeContainer } = require("../utils/components");
const { getUserStats, getUserRank } = require("../services/guessGame");

const DEFAULT_AVATAR = "https://cdn.discordapp.com/embed/avatars/0.png";

function resolveMemberDisplay(member, user, userId, interaction) {
    if (member?.displayName) {
        return {
            avatarUrl: member.displayAvatarURL({ size: 256 }) || DEFAULT_AVATAR,
        };
    }

    if (user) {
        return {
            avatarUrl: user.displayAvatarURL({ size: 256 }) || DEFAULT_AVATAR,
        };
    }

    if (userId === interaction.user.id) {
        return {
            avatarUrl: interaction.user.displayAvatarURL({ size: 256 }) || DEFAULT_AVATAR,
        };
    }

    return { avatarUrl: DEFAULT_AVATAR };
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess-profile")
        .setDescription("View guess-game stats for yourself or another member")
        .addUserOption((option) =>
            option
                .setName("member")
                .setDescription("The member to view the profile of (leave blank for yourself)")
                .setRequired(false)
        ),

    async execute(interaction) {
        await deferEphemeralV2(interaction);

        const selectedUser = interaction.options.getUser("member");
        const userId = selectedUser?.id ?? interaction.user.id;

        if (selectedUser?.bot) {
            await replyEphemeral(
                interaction,
                createNoticeContainer("Invalid member", "Bots don't have guess-game stats.")
            );
            return;
        }

        let member = interaction.guild.members.cache.get(userId);
        if (!member) {
            member = await interaction.guild.members.fetch(userId).catch(() => null);
        }

        if (!member && userId !== interaction.user.id && !selectedUser) {
            await replyEphemeral(
                interaction,
                createNoticeContainer("Not found", "Could not find that member in this server.")
            );
            return;
        }

        const user = selectedUser ?? interaction.user;
        const { avatarUrl } = resolveMemberDisplay(member, user, userId, interaction);
        const stats = getUserStats(interaction.guild.id, userId);
        const rank = getUserRank(interaction.guild.id, userId);

        await replyEphemeral(
            interaction,
            createProfileContainer({
                userId,
                avatarUrl,
                stats,
                rank,
                isSelf: userId === interaction.user.id,
            })
        );
    },
};
