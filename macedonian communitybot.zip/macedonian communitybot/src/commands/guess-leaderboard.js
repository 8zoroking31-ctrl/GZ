const { SlashCommandBuilder } = require("discord.js");
const { getLeaderboardCount, getLeaderboardPage } = require("../services/guessGame");
const { createLeaderboardContainer, LEADERBOARD_PAGE_SIZE } = require("../utils/components");
const { replyPublicV2 } = require("../utils/replies");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess-leaderboard")
        .setDescription("Top guess-the-number scores in this server"),

    async execute(interaction) {
        const guildId = interaction.guild.id;
        const totalCount = getLeaderboardCount(guildId);
        const rows = getLeaderboardPage(guildId, 1, LEADERBOARD_PAGE_SIZE);

        await replyPublicV2(
            interaction,
            createLeaderboardContainer(rows, {
                guildId,
                page: 1,
                totalCount,
            })
        );
    },
};
