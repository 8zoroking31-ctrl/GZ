const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChannelType,
} = require("discord.js");
const config = require("../loadConfig");
const { replyEphemeral } = require("../utils/replies");
const { createNoticeContainer, createSetupSummaryContainer } = require("../utils/components");
const {
    getGuildSettings,
    setGuildChannel,
    setGuildEnabled,
} = require("../services/guildSettings");
const { scheduleNextRound } = require("../services/guessScheduler");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess-setup")
        .setDescription("One-time setup for the guess-the-number game")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addChannelOption((option) =>
            option
                .setName("channel")
                .setDescription("Text channel where rounds are posted (e.g. #general)")
                .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
                .setRequired(true)
        )
        .addIntegerOption((option) =>
            option
                .setName("interval_minutes")
                .setDescription("Minutes between rounds (5 to 120)")
                .setMinValue(config.guessGame.minIntervalMinutes)
                .setMaxValue(config.guessGame.maxIntervalMinutes)
                .setRequired(true)
        ),

    async execute(interaction, client) {
        const existing = getGuildSettings(interaction.guild.id);
        if (existing?.game_channel_id) {
            await replyEphemeral(
                interaction,
                createNoticeContainer(
                    "Setup already done",
                    "The guess game is already configured for this server.\nUse **`/guess-config`** to change the channel, interval, or on/off status."
                )
            );
            return;
        }

        const channel = interaction.options.getChannel("channel");
        const interval = interaction.options.getInteger("interval_minutes");

        const me = interaction.guild.members.me;
        const perms = channel.permissionsFor(me);
        const needed = ["ViewChannel", "SendMessages", "AddReactions"];
        const missing = needed.filter((p) => !perms?.has(p));

        if (missing.length) {
            await replyEphemeral(
                interaction,
                createNoticeContainer(
                    "Missing permissions",
                    `I need these permissions in ${channel}: **${missing.join(", ")}**.`
                )
            );
            return;
        }

        setGuildChannel(interaction.guild.id, channel.id, interval);
        setGuildEnabled(interaction.guild.id, true);
        scheduleNextRound(client, interaction.guild.id);

        const updated = getGuildSettings(interaction.guild.id);

        await replyEphemeral(
            interaction,
            createSetupSummaryContainer({
                status: "on",
                channelMention: `${channel}`,
                intervalMinutes: updated.interval_minutes,
            })
        );
    },
};
