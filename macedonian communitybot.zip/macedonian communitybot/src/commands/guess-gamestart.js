const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { replyEphemeral } = require("../utils/replies");
const { createNoticeContainer } = require("../utils/components");
const { getGuildSettings } = require("../services/guildSettings");
const { adminForceStartRound } = require("../services/guessGameControl");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess-gamestart")
        .setDescription("Start a guess round now (re-enables the game if it was disabled)")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        if (!interaction.memberPermissions.has(PermissionFlagsBits.Administrator)) {
            await replyEphemeral(
                interaction,
                createNoticeContainer(
                    "Not allowed",
                    "You need the **Administrator** permission to use this command."
                )
            );
            return;
        }

        const settings = getGuildSettings(interaction.guild.id);
        if (!settings?.game_channel_id) {
            await replyEphemeral(
                interaction,
                createNoticeContainer(
                    "Setup required",
                    "Run **`/guess-setup`** first with a channel and interval."
                )
            );
            return;
        }

        const wasDisabled = settings.enabled !== 1;
        const result = await adminForceStartRound(interaction.client, interaction.guild.id);

        if (!result.ok) {
            const reason =
                result.reason === "permissions"
                    ? "I need **View Channel**, **Send Messages**, and **Add Reactions** in the game channel."
                    : result.reason === "active"
                      ? "A round is already in progress."
                      : "Could not start a round right now.";
            await replyEphemeral(interaction, createNoticeContainer("Failed", reason));
            return;
        }

        const channel = await interaction.guild.channels
            .fetch(settings.game_channel_id)
            .catch(() => null);

        await replyEphemeral(
            interaction,
            createNoticeContainer(
                "Round started",
                (wasDisabled
                    ? "The game was **re-enabled** and a new round was posted"
                    : "A new round was posted") +
                    (channel ? ` in ${channel}.` : ".") +
                    "\n\nThe usual interval applies after this round ends."
            )
        );
    },
};
