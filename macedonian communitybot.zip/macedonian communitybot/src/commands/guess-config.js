const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { getGuildSettings } = require("../services/guildSettings");
const { buildGuessConfigModal } = require("../handlers/guessConfigModal");
const { replyEphemeral } = require("../utils/replies");
const { createNoticeContainer } = require("../utils/components");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess-config")
        .setDescription("Edit guess-the-number settings (channel, on/off, interval)")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        const settings = getGuildSettings(interaction.guild.id);
        if (!settings?.game_channel_id) {
            await replyEphemeral(
                interaction,
                createNoticeContainer(
                    "Setup required",
                    "The guess game has not been set up yet.\nRun **`/guess-setup`** first with a channel and interval."
                )
            );
            return;
        }

        await interaction.showModal(buildGuessConfigModal(settings));
    },
};
