const db = require("../db/sqlite");
const config = require("../loadConfig");
const { getGuildSettings } = require("./guildSettings");
const { createGuessTimeoutContainer } = require("../utils/components");
const { sendComponentsV2 } = require("../utils/replies");

/** @type {Map<string, NodeJS.Timeout>} */
const roundExpiryTimers = new Map();

const listActiveRoundsStmt = db.prepare(`
    SELECT guild_id, expires_at, started_at
    FROM active_rounds
`);

function getRoundDurationMs() {
    return (config.guessGame.roundDurationSeconds || 60) * 1000;
}

function clearRoundExpiry(guildId) {
    const timer = roundExpiryTimers.get(guildId);
    if (timer) {
        clearTimeout(timer);
        roundExpiryTimers.delete(guildId);
    }
}

async function handleRoundExpired(client, guildId) {
    roundExpiryTimers.delete(guildId);

    const { tryExpireRound, closeRoundPromptMessage } = require("./guessGame");
    const now = Date.now();
    const claim = tryExpireRound(guildId, now);

    if (!claim.ok) {
        if (claim.reason === "not_yet" && claim.expiresAt) {
            scheduleRoundExpiry(client, guildId, claim.expiresAt);
        }
        return;
    }

    const secret = claim.round.secret_number;
    const promptMessageId = claim.round.prompt_message_id;

    const settings = getGuildSettings(guildId);
    if (!settings?.game_channel_id) {
        return;
    }

    const channel = await client.channels.fetch(settings.game_channel_id).catch(() => null);

    if (channel?.isTextBased()) {
        await closeRoundPromptMessage(channel, promptMessageId, "expired");
    }

    if (settings.enabled === 1 && channel?.isTextBased()) {
        try {
            await sendComponentsV2(channel, createGuessTimeoutContainer({ secret }));
        } catch (err) {
            console.warn(
                `[CommunityBot] Could not send timeout message in ${channel.id}:`,
                err.message
            );
        }
    }

    if (settings.enabled === 1) {
        const { scheduleNextRound } = require("./guessScheduler");
        scheduleNextRound(client, guildId);
    }

    console.log(`[CommunityBot] Guess round timed out in guild ${guildId} (answer: ${secret})`);
}

function scheduleRoundExpiry(client, guildId, expiresAt) {
    clearRoundExpiry(guildId);

    const delayMs = Math.max(0, expiresAt - Date.now());
    const timer = setTimeout(() => {
        handleRoundExpired(client, guildId).catch((err) => {
            console.error(`[CommunityBot] Round expiry failed for ${guildId}:`, err.message);
        });
    }, delayMs);

    roundExpiryTimers.set(guildId, timer);
}

function restoreRoundTimers(client) {
    for (const row of listActiveRoundsStmt.all()) {
        const expiresAt =
            row.expires_at ?? row.started_at + getRoundDurationMs();
        scheduleRoundExpiry(client, row.guild_id, expiresAt);
    }
}

module.exports = {
    getRoundDurationMs,
    clearRoundExpiry,
    scheduleRoundExpiry,
    restoreRoundTimers,
    handleRoundExpired,
};
