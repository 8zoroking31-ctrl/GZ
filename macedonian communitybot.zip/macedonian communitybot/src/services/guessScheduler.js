const config = require("../loadConfig");
const { listScheduledGuilds, getGuildSettings } = require("./guildSettings");
const { startRound, hasActiveRound } = require("./guessGame");

const defaultIntervalMinutes = config.guessGame.defaultIntervalMinutes;

/** @type {Map<string, NodeJS.Timeout>} */
const guildTimers = new Map();

function msUntilNextRun(settings) {
    const intervalMs = (settings.interval_minutes || defaultIntervalMinutes) * 60 * 1000;
    const lastEnded = settings.last_round_ended_at;
    if (!lastEnded) return 0;
    const elapsed = Date.now() - lastEnded;
    return Math.max(0, intervalMs - elapsed);
}

function clearGuildTimer(guildId) {
    const existing = guildTimers.get(guildId);
    if (existing) {
        clearTimeout(existing);
        guildTimers.delete(guildId);
    }
}

async function runScheduledRound(client, guildId) {
    clearGuildTimer(guildId);

    const settings = getGuildSettings(guildId);
    if (!settings?.game_channel_id || settings.enabled !== 1) return;

    if (hasActiveRound(guildId)) {
        scheduleNextRound(client, guildId, { delayMs: 5 * 60 * 1000 });
        return;
    }

    const channel = await client.channels.fetch(settings.game_channel_id).catch(() => null);
    if (!channel || !channel.isTextBased()) {
        console.warn(`[CommunityBot] Game channel missing for guild ${guildId}`);
        return;
    }

    const result = await startRound(client, guildId, channel);
    if (!result.ok) {
        if (result.reason === "permissions") {
            console.warn(`[CommunityBot] Missing permissions in game channel for guild ${guildId}`);
        }
        scheduleNextRound(client, guildId, { delayMs: 10 * 60 * 1000 });
        return;
    }

    console.log(`[CommunityBot] Started guess round in guild ${guildId}`);
}

function computeScheduleDelayMs(settings, options = {}) {
    if (options.delayMs !== undefined) {
        return options.delayMs;
    }

    if (settings.last_round_ended_at == null) {
        return config.guessGame.firstRoundDelayMs ?? 0;
    }

    const until = msUntilNextRun(settings);
    if (until > 0) {
        return until;
    }

    return (settings.interval_minutes || defaultIntervalMinutes) * 60 * 1000;
}

function cancelGuildSchedule(guildId) {
    clearGuildTimer(guildId);
}

function scheduleNextRound(client, guildId, options = {}) {
    clearGuildTimer(guildId);

    const settings = getGuildSettings(guildId);
    if (!settings?.game_channel_id || settings.enabled !== 1) return;

    const delayMs = computeScheduleDelayMs(settings, options);

    const timer = setTimeout(() => {
        runScheduledRound(client, guildId).catch((err) => {
            console.error(`[CommunityBot] Scheduled round failed for ${guildId}:`, err.message);
        });
    }, delayMs);

    guildTimers.set(guildId, timer);
}

function startGuessScheduler(client) {
    for (const settings of listScheduledGuilds()) {
        const delay = msUntilNextRun(settings);
        scheduleNextRound(client, settings.guild_id, { delayMs: delay });
        console.log(
            `[CommunityBot] Scheduled guess game for guild ${settings.guild_id} in ${Math.round(delay / 60000)} min`
        );
    }
}

function stopGuessScheduler() {
    for (const guildId of guildTimers.keys()) {
        clearGuildTimer(guildId);
    }
}

module.exports = {
    startGuessScheduler,
    stopGuessScheduler,
    cancelGuildSchedule,
    scheduleNextRound,
    runScheduledRound,
};
