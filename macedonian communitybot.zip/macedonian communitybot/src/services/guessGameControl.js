const { getGuildSettings, setGuildEnabled, isGameEnabled } = require("./guildSettings");
const { cancelGuildSchedule } = require("./guessScheduler");
const {
    hasActiveRound,
    abortActiveRound,
    startRound,
} = require("./guessGame");

async function disableGuessGame(client, guildId) {
    cancelGuildSchedule(guildId);
    await abortActiveRound(client, guildId, { closeReason: "ended", markEnded: false });
    setGuildEnabled(guildId, false);
}

async function adminForceStartRound(client, guildId) {
    const settings = getGuildSettings(guildId);
    if (!settings?.game_channel_id) {
        return { ok: false, reason: "not_setup" };
    }

    if (!isGameEnabled(settings)) {
        setGuildEnabled(guildId, true);
    }

    cancelGuildSchedule(guildId);

    if (hasActiveRound(guildId)) {
        await abortActiveRound(client, guildId, { closeReason: "ended", markEnded: false });
    }

    const channel = await client.channels.fetch(settings.game_channel_id).catch(() => null);
    if (!channel?.isTextBased()) {
        return { ok: false, reason: "channel" };
    }

    return startRound(client, guildId, channel);
}

module.exports = {
    disableGuessGame,
    adminForceStartRound,
};
