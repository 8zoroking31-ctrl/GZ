const crypto = require("crypto");
const db = require("../db/sqlite");
const config = require("../loadConfig");
const { getGuildSettings, markRoundEnded } = require("./guildSettings");

const getActiveRoundStmt = db.prepare(`
    SELECT guild_id, secret_number, prompt_message_id, started_at, expires_at
    FROM active_rounds
    WHERE guild_id = ?
`);

const insertRoundStmt = db.prepare(`
    INSERT INTO active_rounds (guild_id, secret_number, prompt_message_id, started_at, expires_at)
    VALUES (?, ?, ?, ?, ?)
`);

const deleteRoundStmt = db.prepare(`DELETE FROM active_rounds WHERE guild_id = ?`);

const clearAttemptsStmt = db.prepare(`DELETE FROM round_attempts WHERE guild_id = ?`);

const incrementAttemptStmt = db.prepare(`
    INSERT INTO round_attempts (guild_id, user_id, attempts)
    VALUES (?, ?, 1)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET attempts = attempts + 1
`);

const getAttemptsStmt = db.prepare(`
    SELECT attempts FROM round_attempts WHERE guild_id = ? AND user_id = ?
`);

const addScoreStmt = db.prepare(`
    INSERT INTO scores (guild_id, user_id, points, wins, rounds_played, total_guesses)
    VALUES (?, ?, ?, 1, 0, 0)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
        points = points + excluded.points,
        wins = wins + 1
`);

const recordGuessStmt = db.prepare(`
    INSERT INTO scores (guild_id, user_id, points, wins, rounds_played, total_guesses)
    VALUES (?, ?, 0, 0, ?, 1)
    ON CONFLICT(guild_id, user_id) DO UPDATE SET
        total_guesses = total_guesses + 1,
        rounds_played = rounds_played + excluded.rounds_played
`);

const getUserStatsStmt = db.prepare(`
    SELECT points, wins, rounds_played, total_guesses
    FROM scores
    WHERE guild_id = ? AND user_id = ?
`);

const countScoresStmt = db.prepare(`
    SELECT COUNT(*) AS count
    FROM scores
    WHERE guild_id = ? AND left_at IS NULL
`);

const topScoresStmt = db.prepare(`
    SELECT user_id, points, wins, total_guesses
    FROM scores
    WHERE guild_id = ? AND left_at IS NULL
    ORDER BY points DESC, wins DESC, total_guesses DESC
    LIMIT ?
`);

const allScoresOrderedStmt = db.prepare(`
    SELECT user_id, points, wins, total_guesses
    FROM scores
    WHERE guild_id = ? AND left_at IS NULL
    ORDER BY points DESC, wins DESC, total_guesses DESC
`);

const listScoreUserIdsStmt = db.prepare(`
    SELECT user_id FROM scores WHERE guild_id = ?
`);

const markScoreLeftStmt = db.prepare(`
    UPDATE scores SET left_at = ? WHERE guild_id = ? AND user_id = ?
`);

const markScoreActiveStmt = db.prepare(`
    UPDATE scores SET left_at = NULL WHERE guild_id = ? AND user_id = ?
`);

const isScoreActiveStmt = db.prepare(`
    SELECT left_at FROM scores WHERE guild_id = ? AND user_id = ?
`);

const { createGuessPromptContainer, createGuessPromptClosedContainer } = require("../utils/components");
const { sendComponentsV2, componentsV2Payload } = require("../utils/replies");

async function closeRoundPromptMessage(channel, promptMessageId, reason) {
    if (!promptMessageId || !channel?.isTextBased()) return;

    try {
        const promptMessage = await channel.messages.fetch(promptMessageId);
        await promptMessage.edit(
            componentsV2Payload(createGuessPromptClosedContainer({ reason }))
        );
    } catch (err) {
        console.warn(
            `[CommunityBot] Could not update round prompt ${promptMessageId}:`,
            err.message
        );
    }
}

function pickSecret() {
    return crypto.randomInt(1, 101);
}

function parseGuess(content) {
    const trimmed = content.trim();
    if (!/^-?\d+$/.test(trimmed)) return null;
    const value = Number(trimmed);
    if (!Number.isInteger(value) || value < 1 || value > 100) return null;
    return value;
}

function computePoints(attempts) {
    const { pointsBase, pointsBonusMax } = config.guessGame;
    const bonus = Math.max(0, pointsBonusMax - (attempts - 1));
    return pointsBase + bonus;
}

function getActiveRound(guildId) {
    return getActiveRoundStmt.get(guildId) || null;
}

function hasActiveRound(guildId) {
    return Boolean(getActiveRound(guildId));
}

async function startRound(client, guildId, channel) {
    if (hasActiveRound(guildId)) {
        return { ok: false, reason: "active" };
    }

    const me = channel.guild.members.me;
    const perms = channel.permissionsFor(me);
    if (!perms?.has(["SendMessages", "AddReactions", "ViewChannel"])) {
        return { ok: false, reason: "permissions" };
    }

    const { getRoundDurationMs, scheduleRoundExpiry } = require("./guessRoundTimer");

    const secret = pickSecret();
    const startedAt = Date.now();
    const expiresAt = startedAt + getRoundDurationMs();
    const expiresUnix = Math.floor(expiresAt / 1000);

    const prompt = await sendComponentsV2(
        channel,
        createGuessPromptContainer({ expiresUnix })
    );

    insertRoundStmt.run(guildId, secret, prompt.id, startedAt, expiresAt);
    clearAttemptsStmt.run(guildId);
    scheduleRoundExpiry(client, guildId, expiresAt);

    if (
        process.env.GUESS_TEST_REVEAL_SECRET === "1" ||
        process.env.GUESS_TEST_REVEAL_SECRET === "true"
    ) {
        console.log(`[CommunityBot] TEST round started — secret number: ${secret} (guild ${guildId})`);
    }

    return { ok: true, secret, messageId: prompt.id };
}

function incrementAttempts(guildId, userId) {
    incrementAttemptStmt.run(guildId, userId);
    const row = getAttemptsStmt.get(guildId, userId);
    return row?.attempts ?? 1;
}

function recordGuessStats(guildId, userId, attemptsInRound) {
    markScoreMemberActive(guildId, userId);
    const firstGuessInRound = attemptsInRound === 1 ? 1 : 0;
    recordGuessStmt.run(guildId, userId, firstGuessInRound);
}

function getUserStats(guildId, userId) {
    const row = getUserStatsStmt.get(guildId, userId);
    return {
        points: row?.points ?? 0,
        wins: row?.wins ?? 0,
        rounds_played: row?.rounds_played ?? 0,
        total_guesses: row?.total_guesses ?? 0,
    };
}

function getUserRank(guildId, userId) {
    const stats = getUserStats(guildId, userId);
    if (stats.points === 0 && stats.wins === 0 && stats.total_guesses === 0) {
        return null;
    }

    const activeRow = isScoreActiveStmt.get(guildId, userId);
    if (activeRow?.left_at != null) {
        return null;
    }

    const ranked = assignCompetitionRanks(allScoresOrderedStmt.all(guildId));
    const row = ranked.find((entry) => entry.user_id === userId);
    return row?.rank ?? null;
}

function awardWin(guildId, userId, attempts) {
    const points = computePoints(attempts);
    addScoreStmt.run(guildId, userId, points);
    return points;
}

function scoreSortKey(row) {
    return `${row.points}\0${row.wins}\0${row.total_guesses}`;
}

function assignCompetitionRanks(rows) {
    let rank = 0;
    let index = 0;
    let prevKey = null;

    return rows.map((row) => {
        index += 1;
        const key = scoreSortKey(row);
        if (key !== prevKey) {
            rank = index;
            prevKey = key;
        }
        return { ...row, rank };
    });
}

function tryWinRound(guildId, userId, attempts, now) {
    db.exec("BEGIN IMMEDIATE");
    try {
        const round = getActiveRoundStmt.get(guildId);
        if (!round) {
            db.exec("ROLLBACK");
            return { ok: false, reason: "no_round" };
        }
        if (now > round.expires_at) {
            db.exec("ROLLBACK");
            return { ok: false, reason: "expired" };
        }

        deleteRoundStmt.run(guildId);
        clearAttemptsStmt.run(guildId);
        markRoundEnded(guildId, now);

        const points = computePoints(attempts);
        addScoreStmt.run(guildId, userId, points);

        db.exec("COMMIT");
        return { ok: true, round, points };
    } catch (error) {
        try {
            db.exec("ROLLBACK");
        } catch {
            // ignore nested rollback failure
        }
        throw error;
    }
}

function tryExpireRound(guildId, now) {
    db.exec("BEGIN IMMEDIATE");
    try {
        const round = getActiveRoundStmt.get(guildId);
        if (!round) {
            db.exec("ROLLBACK");
            return { ok: false, reason: "no_round" };
        }
        if (now < round.expires_at) {
            db.exec("ROLLBACK");
            return { ok: false, reason: "not_yet", expiresAt: round.expires_at };
        }

        deleteRoundStmt.run(guildId);
        clearAttemptsStmt.run(guildId);
        markRoundEnded(guildId, now);

        db.exec("COMMIT");
        return { ok: true, round };
    } catch (error) {
        try {
            db.exec("ROLLBACK");
        } catch {
            // ignore nested rollback failure
        }
        throw error;
    }
}

function endRound(guildId) {
    const { clearRoundExpiry } = require("./guessRoundTimer");
    clearRoundExpiry(guildId);
    deleteRoundStmt.run(guildId);
    clearAttemptsStmt.run(guildId);
    markRoundEnded(guildId);
}

async function abortActiveRound(client, guildId, options = {}) {
    const { closeReason = "ended", markEnded = false } = options;
    const { clearRoundExpiry } = require("./guessRoundTimer");

    const round = getActiveRound(guildId);
    clearRoundExpiry(guildId);

    if (!round) {
        return false;
    }

    const settings = getGuildSettings(guildId);
    if (settings?.game_channel_id) {
        const channel = await client.channels.fetch(settings.game_channel_id).catch(() => null);
        if (channel?.isTextBased()) {
            await closeRoundPromptMessage(channel, round.prompt_message_id, closeReason);
        }
    }

    deleteRoundStmt.run(guildId);
    clearAttemptsStmt.run(guildId);
    if (markEnded) {
        markRoundEnded(guildId);
    }

    return true;
}

function isRoundExpired(round) {
    if (!round?.expires_at) return false;
    return Date.now() > round.expires_at;
}

function getLeaderboard(guildId, limit = 10) {
    return topScoresStmt.all(guildId, limit);
}

function getLeaderboardCount(guildId) {
    const row = countScoresStmt.get(guildId);
    return row?.count ?? 0;
}

function getLeaderboardPage(guildId, page, pageSize = 10) {
    const ranked = assignCompetitionRanks(allScoresOrderedStmt.all(guildId));
    const safePage = Math.max(1, page);
    const offset = (safePage - 1) * pageSize;
    return ranked.slice(offset, offset + pageSize);
}

function markScoreMemberLeft(guildId, userId, timestamp = Date.now()) {
    markScoreLeftStmt.run(timestamp, guildId, userId);
}

function markScoreMemberActive(guildId, userId) {
    markScoreActiveStmt.run(guildId, userId);
}

async function reconcileScoreMembership(client, guildId) {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;

    const rows = listScoreUserIdsStmt.all(guildId);
    for (const row of rows) {
        const member = await guild.members.fetch(row.user_id).catch(() => null);
        if (member) {
            markScoreMemberActive(guildId, row.user_id);
        } else {
            markScoreMemberLeft(guildId, row.user_id);
        }
    }
}

async function handleStaleRound(client, message, round) {
    await message.react("⏱️").catch(() => {});
    const { handleRoundExpired } = require("./guessRoundTimer");
    handleRoundExpired(client, message.guild.id).catch((err) => {
        console.warn(`[CommunityBot] Expire round after stale guess failed:`, err.message);
    });
    return { outcome: "stale" };
}

async function handleGuess(client, message) {
    if (message.author.bot || !message.guild) return null;

    const settings = getGuildSettings(message.guild.id);
    if (!settings?.game_channel_id || settings.enabled !== 1) return null;
    if (message.channel.id !== settings.game_channel_id) return null;

    const guess = parseGuess(message.content);
    if (guess === null) return null;

    const guildId = message.guild.id;
    let round = getActiveRound(guildId);
    if (!round) return null;

    if (isRoundExpired(round)) {
        return handleStaleRound(client, message, round);
    }

    const userId = message.author.id;
    const attempts = incrementAttempts(guildId, userId);
    recordGuessStats(guildId, userId, attempts);

    async function reactToGuess(primaryEmoji) {
        await message.react(primaryEmoji).catch(() => {});
        if (guess === 67) {
            await message.react("😂").catch(() => {});
        }
    }

    if (guess > round.secret_number) {
        round = getActiveRound(guildId);
        if (!round || isRoundExpired(round)) {
            return handleStaleRound(client, message, round);
        }
        await reactToGuess("⬇️");
        return { outcome: "high", attempts };
    }

    if (guess < round.secret_number) {
        round = getActiveRound(guildId);
        if (!round || isRoundExpired(round)) {
            return handleStaleRound(client, message, round);
        }
        await reactToGuess("⬆️");
        return { outcome: "low", attempts };
    }

    const now = Date.now();
    const claim = tryWinRound(guildId, userId, attempts, now);

    if (!claim.ok) {
        if (claim.reason === "expired") {
            return handleStaleRound(client, message, round);
        }
        if (claim.reason === "no_round") {
            await message.react("⏱️").catch(() => {});
            return { outcome: "lost_race" };
        }
        return null;
    }

    const { clearRoundExpiry } = require("./guessRoundTimer");
    clearRoundExpiry(guildId);

    await reactToGuess("🎉");
    await closeRoundPromptMessage(message.channel, claim.round.prompt_message_id, "won");

    return {
        outcome: "win",
        attempts,
        points: claim.points,
        secret: claim.round.secret_number,
        userId,
        username: message.author.displayName || message.author.username,
    };
}

module.exports = {
    parseGuess,
    computePoints,
    getActiveRound,
    hasActiveRound,
    startRound,
    endRound,
    abortActiveRound,
    tryExpireRound,
    getLeaderboard,
    getLeaderboardCount,
    getLeaderboardPage,
    markScoreMemberLeft,
    markScoreMemberActive,
    reconcileScoreMembership,
    getUserStats,
    getUserRank,
    handleGuess,
    closeRoundPromptMessage,
};
