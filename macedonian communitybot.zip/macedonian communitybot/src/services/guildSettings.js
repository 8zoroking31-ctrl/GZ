const db = require("../db/sqlite");
const config = require("../loadConfig");

const getGuildStmt = db.prepare(`
    SELECT guild_id, game_channel_id, interval_minutes, enabled, last_round_ended_at
    FROM guild_settings
    WHERE guild_id = ?
`);

const upsertGuildStmt = db.prepare(`
    INSERT INTO guild_settings (guild_id, game_channel_id, interval_minutes, enabled, last_round_ended_at)
    VALUES (@guild_id, @game_channel_id, @interval_minutes, @enabled, @last_round_ended_at)
    ON CONFLICT(guild_id) DO UPDATE SET
        game_channel_id = COALESCE(excluded.game_channel_id, guild_settings.game_channel_id),
        interval_minutes = COALESCE(excluded.interval_minutes, guild_settings.interval_minutes),
        enabled = COALESCE(excluded.enabled, guild_settings.enabled),
        last_round_ended_at = COALESCE(excluded.last_round_ended_at, guild_settings.last_round_ended_at)
`);

const listScheduledGuildsStmt = db.prepare(`
    SELECT guild_id, game_channel_id, interval_minutes, enabled, last_round_ended_at
    FROM guild_settings
    WHERE game_channel_id IS NOT NULL AND enabled = 1
`);

function getGuildSettings(guildId) {
    return getGuildStmt.get(guildId) || null;
}

/** No saved row yet → default enabled; otherwise use last saved on/off. */
function isGameEnabled(settings) {
    if (!settings) return true;
    return Number(settings.enabled) === 1;
}

function setGuildChannel(guildId, channelId, intervalMinutes) {
    const existing = getGuildSettings(guildId);
    const interval =
        intervalMinutes ??
        existing?.interval_minutes ??
        config.guessGame.defaultIntervalMinutes;
    const enabled = existing != null ? Number(existing.enabled) === 1 : 1;

    upsertGuildStmt.run({
        guild_id: guildId,
        game_channel_id: channelId,
        interval_minutes: interval,
        enabled: enabled ? 1 : 0,
        last_round_ended_at: existing?.last_round_ended_at ?? null,
    });
}

function setGuildInterval(guildId, intervalMinutes) {
    const existing = getGuildSettings(guildId);
    if (!existing) {
        upsertGuildStmt.run({
            guild_id: guildId,
            game_channel_id: null,
            interval_minutes: intervalMinutes,
            enabled: 0,
            last_round_ended_at: null,
        });
        return;
    }

    upsertGuildStmt.run({
        guild_id: guildId,
        game_channel_id: existing.game_channel_id,
        interval_minutes: intervalMinutes,
        enabled: existing.enabled,
        last_round_ended_at: existing.last_round_ended_at,
    });
}

function setGuildEnabled(guildId, enabled) {
    const existing = getGuildSettings(guildId);
    if (!existing) return;

    upsertGuildStmt.run({
        guild_id: guildId,
        game_channel_id: existing.game_channel_id,
        interval_minutes: existing.interval_minutes,
        enabled: enabled ? 1 : 0,
        last_round_ended_at: existing.last_round_ended_at,
    });
}

function markRoundEnded(guildId, timestamp = Date.now()) {
    const existing = getGuildSettings(guildId);
    if (!existing) return;

    upsertGuildStmt.run({
        guild_id: guildId,
        game_channel_id: existing.game_channel_id,
        interval_minutes: existing.interval_minutes,
        enabled: existing.enabled,
        last_round_ended_at: timestamp,
    });
}

function listScheduledGuilds() {
    return listScheduledGuildsStmt.all();
}

module.exports = {
    getGuildSettings,
    isGameEnabled,
    setGuildChannel,
    setGuildInterval,
    setGuildEnabled,
    markRoundEnded,
    listScheduledGuilds,
};
