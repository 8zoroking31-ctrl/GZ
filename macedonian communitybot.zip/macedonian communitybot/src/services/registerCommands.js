const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

function loadCommandJson() {
    const commands = [];
    const commandsPath = path.join(__dirname, "..", "commands");
    const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        if (command.data) {
            commands.push(command.data.toJSON());
        }
    }

    return commands;
}

async function registerGuildCommands({ token, clientId, guildId, clearGlobal = true }) {
    const commands = loadCommandJson();
    const rest = new REST({ version: "10" }).setToken(token);

    await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
        body: commands,
    });

    if (clearGlobal) {
        await rest.put(Routes.applicationCommands(clientId), {
            body: [],
        });
    }

    return commands.length;
}

module.exports = { registerGuildCommands, loadCommandJson };
