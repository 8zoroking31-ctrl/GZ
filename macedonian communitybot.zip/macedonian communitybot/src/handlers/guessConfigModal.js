const {
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    LabelBuilder,
    ChannelSelectMenuBuilder,
    ChannelType,
    RadioGroupBuilder,
    RadioGroupOptionBuilder,
} = require("discord.js");
const config = require("../loadConfig");
const {
    getGuildSettings,
    isGameEnabled,
    setGuildChannel,
    setGuildEnabled,
} = require("../services/guildSettings");
const { scheduleNextRound } = require("../services/guessScheduler");
const { disableGuessGame } = require("../services/guessGameControl");
const { createNoticeContainer, createSetupSummaryContainer } = require("../utils/components");
const { replyEphemeral } = require("../utils/replies");

const GUESS_CONFIG_MODAL_ID = "guess_config_modal";
const FIELD_CHANNEL = "guess_config_channel";
const FIELD_ENABLED = "guess_config_enabled";
const FIELD_INTERVAL = "guess_config_interval";

const ENABLED_VALUE = "enabled";
const DISABLED_VALUE = "disabled";

function buildGuessConfigModal(settings) {
    const { minIntervalMinutes, maxIntervalMinutes } = config.guessGame;
    const interval = settings?.interval_minutes ?? config.guessGame.defaultIntervalMinutes;
    const enabledSelected = isGameEnabled(settings);

    const channelSelect = new ChannelSelectMenuBuilder()
        .setCustomId(FIELD_CHANNEL)
        .setPlaceholder("Choose a text channel")
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);

    if (settings?.game_channel_id) {
        channelSelect.setDefaultChannels(settings.game_channel_id);
    }

    const channelLabel = new LabelBuilder()
        .setLabel("Game channel")
        .setDescription("Rounds are posted in this channel.")
        .setChannelSelectMenuComponent(channelSelect);

    const enabledRadio = new RadioGroupBuilder()
        .setCustomId(FIELD_ENABLED)
        .setRequired(true)
        .addOptions(
            new RadioGroupOptionBuilder()
                .setLabel("Enabled")
                .setDescription("Scheduled guess rounds run in the game channel.")
                .setValue(ENABLED_VALUE)
                .setDefault(enabledSelected),
            new RadioGroupOptionBuilder()
                .setLabel("Disabled")
                .setDescription("Stops the current round and schedule. Use /guess-gamestart to run a round and turn the game back on.")
                .setValue(DISABLED_VALUE)
                .setDefault(!enabledSelected)
        );

    const enabledLabel = new LabelBuilder()
        .setLabel("Game status")
        .setDescription("Pick one: the game is either on or off.")
        .setRadioGroupComponent(enabledRadio);

    const intervalInput = new TextInputBuilder()
        .setCustomId(FIELD_INTERVAL)
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setValue(String(interval));

    const intervalLabel = new LabelBuilder()
        .setLabel(`Round interval (${minIntervalMinutes} to ${maxIntervalMinutes})`)
        .setDescription(
            "Enter a whole number in minutes only. You do not need to type min or sec."
        )
        .setTextInputComponent(intervalInput);

    return new ModalBuilder()
        .setCustomId(GUESS_CONFIG_MODAL_ID)
        .setTitle("Guess game settings")
        .addLabelComponents(channelLabel, intervalLabel, enabledLabel);
}

async function handleGuessConfigModalSubmit(interaction, client) {
    const existing = getGuildSettings(interaction.guild.id);
    if (!existing?.game_channel_id) {
        await replyEphemeral(
            interaction,
            createNoticeContainer(
                "Setup required",
                "The guess game has not been set up yet.\nRun **`/guess-setup`** first with a channel and interval."
            )
        );
        return;
    }

    const channelId = interaction.fields.getSelectedChannels(FIELD_CHANNEL).first()?.id;
    if (!channelId) {
        await replyEphemeral(
            interaction,
            createNoticeContainer("Channel required", "Choose a text channel for the game.")
        );
        return;
    }

    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
    if (!channel?.isTextBased()) {
        await replyEphemeral(
            interaction,
            createNoticeContainer("Invalid channel", "That channel cannot be used for the game.")
        );
        return;
    }

    const me = interaction.guild.members.me;
    const perms = channel.permissionsFor(me);
    const needed = ["ViewChannel", "SendMessages", "AddReactions"];
    const missing = needed.filter((p) => !perms?.has(p));
    if (missing.length) {
        await replyEphemeral(
            interaction,
            createNoticeContainer(
                "Missing permissions",
                `I need **${missing.join(", ")}** in ${channel}.`
            )
        );
        return;
    }

    const enabledChoice = interaction.fields.getRadioGroup(FIELD_ENABLED);
    const enabled = enabledChoice === ENABLED_VALUE;

    const intervalRaw = interaction.fields.getTextInputValue(FIELD_INTERVAL).trim();
    const interval = Number(intervalRaw);
    if (
        !Number.isInteger(interval) ||
        interval < config.guessGame.minIntervalMinutes ||
        interval > config.guessGame.maxIntervalMinutes
    ) {
        await replyEphemeral(
            interaction,
            createNoticeContainer(
                "Invalid interval",
                `Use a whole number of **minutes** between **${config.guessGame.minIntervalMinutes}** and **${config.guessGame.maxIntervalMinutes}**.`
            )
        );
        return;
    }

    setGuildChannel(interaction.guild.id, channelId, interval);

    if (enabled) {
        setGuildEnabled(interaction.guild.id, true);
        scheduleNextRound(client, interaction.guild.id);
    } else {
        await disableGuessGame(client, interaction.guild.id);
    }

    const updated = getGuildSettings(interaction.guild.id);

    await replyEphemeral(
        interaction,
        createSetupSummaryContainer({
            status: updated.enabled ? "on" : "off",
            channelMention: `${channel}`,
            intervalMinutes: updated.interval_minutes,
        })
    );
}

module.exports = {
    GUESS_CONFIG_MODAL_ID,
    FIELD_CHANNEL,
    FIELD_ENABLED,
    FIELD_INTERVAL,
    buildGuessConfigModal,
    handleGuessConfigModalSubmit,
};
