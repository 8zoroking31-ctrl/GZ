const { getLeaderboardCount, getLeaderboardPage } = require("../services/guessGame");
const { createLeaderboardContainer, LEADERBOARD_PAGE_SIZE } = require("../utils/components");
const { componentsV2Payload } = require("../utils/replies");

const LEADERBOARD_BUTTON_PREFIX = "guess_lb";

function parseLeaderboardButtonId(customId) {
    if (!customId.startsWith(`${LEADERBOARD_BUTTON_PREFIX}:`)) return null;

    const parts = customId.split(":");
    if (parts.length !== 3) return null;

    const guildId = parts[1];
    const page = Number(parts[2]);
    if (!guildId || !Number.isInteger(page) || page < 1) return null;

    return { guildId, page };
}

async function handleLeaderboardButton(interaction) {
    const parsed = parseLeaderboardButtonId(interaction.customId);
    if (!parsed || parsed.guildId !== interaction.guild?.id) {
        return false;
    }

    const totalCount = getLeaderboardCount(interaction.guild.id);
    const totalPages = Math.max(1, Math.ceil(totalCount / LEADERBOARD_PAGE_SIZE));
    const page = Math.min(parsed.page, totalPages);

    const rows = getLeaderboardPage(interaction.guild.id, page, LEADERBOARD_PAGE_SIZE);
    const container = createLeaderboardContainer(rows, {
        guildId: interaction.guild.id,
        page,
        totalCount,
    });

    await interaction.update(componentsV2Payload(container));
    return true;
}

function isLeaderboardButton(customId) {
    return customId?.startsWith(`${LEADERBOARD_BUTTON_PREFIX}:`);
}

module.exports = {
    handleLeaderboardButton,
    isLeaderboardButton,
};
