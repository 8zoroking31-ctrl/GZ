const { handleGuess } = require("../services/guessGame");
const { scheduleNextRound } = require("../services/guessScheduler");
const { createGuessWinContainer } = require("../utils/components");
const { sendComponentsV2 } = require("../utils/replies");

async function handleGuessMessage(client, message) {
    const result = await handleGuess(client, message);
    if (!result || result.outcome !== "win") return;

    const channel = message.channel;

    try {
        await sendComponentsV2(
            channel,
            createGuessWinContainer({
                userId: result.userId,
                secret: result.secret,
                attempts: result.attempts,
                points: result.points,
            })
        );
    } catch (err) {
        console.warn(`[CommunityBot] Could not send win message in ${channel.id}:`, err.message);
    }

    scheduleNextRound(client, message.guild.id);
}

module.exports = { handleGuessMessage };
