const SCHEMA_VERSION = 5;

function getSchemaVersion(db) {
    db.exec(`
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    `);

    const row = db.prepare("SELECT value FROM app_settings WHERE key = 'schema_version'").get();
    return row ? Number(row.value) : 0;
}

function setSchemaVersion(db, version) {
    db.prepare(
        "INSERT OR REPLACE INTO app_settings (key, value) VALUES ('schema_version', ?)"
    ).run(String(version));
}

function migrateToV1(db) {
    db.exec(`
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id TEXT PRIMARY KEY,
            game_channel_id TEXT,
            interval_minutes INTEGER NOT NULL DEFAULT 30,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_round_ended_at INTEGER
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS active_rounds (
            guild_id TEXT PRIMARY KEY,
            secret_number INTEGER NOT NULL,
            prompt_message_id TEXT NOT NULL,
            started_at INTEGER NOT NULL
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS round_attempts (
            guild_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, user_id)
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS scores (
            guild_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            points INTEGER NOT NULL DEFAULT 0,
            wins INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, user_id)
        )
    `);

    db.exec(`
        CREATE INDEX IF NOT EXISTS idx_scores_guild_points
        ON scores(guild_id, points DESC)
    `);
}

function migrateToV2(db) {
    db.prepare(
        "UPDATE guild_settings SET interval_minutes = 30 WHERE interval_minutes = 45"
    ).run();
}

function migrateToV3(db) {
    const columns = db.prepare("PRAGMA table_info(scores)").all();
    if (!columns.some((col) => col.name === "rounds_played")) {
        db.exec("ALTER TABLE scores ADD COLUMN rounds_played INTEGER NOT NULL DEFAULT 0");
    }
    if (!columns.some((col) => col.name === "total_guesses")) {
        db.exec("ALTER TABLE scores ADD COLUMN total_guesses INTEGER NOT NULL DEFAULT 0");
    }
}

function migrateToV4(db) {
    const columns = db.prepare("PRAGMA table_info(active_rounds)").all();
    if (!columns.some((col) => col.name === "expires_at")) {
        db.exec("ALTER TABLE active_rounds ADD COLUMN expires_at INTEGER");
        db.prepare(
            "UPDATE active_rounds SET expires_at = started_at + 60000 WHERE expires_at IS NULL"
        ).run();
    }
}

function migrateToV5(db) {
    const columns = db.prepare("PRAGMA table_info(scores)").all();
    if (!columns.some((col) => col.name === "left_at")) {
        db.exec("ALTER TABLE scores ADD COLUMN left_at INTEGER");
    }
}

function runMigrations(db) {
    const current = getSchemaVersion(db);
    if (current < 1) {
        migrateToV1(db);
        setSchemaVersion(db, 1);
    }
    if (getSchemaVersion(db) < 2) {
        migrateToV2(db);
        setSchemaVersion(db, 2);
    }
    if (getSchemaVersion(db) < 3) {
        migrateToV3(db);
        setSchemaVersion(db, 3);
    }
    if (getSchemaVersion(db) < 4) {
        migrateToV4(db);
        setSchemaVersion(db, 4);
    }
    if (getSchemaVersion(db) < 5) {
        migrateToV5(db);
        setSchemaVersion(db, 5);
    }

    if (getSchemaVersion(db) !== SCHEMA_VERSION) {
        throw new Error(
            `[CommunityBot] Database schema version mismatch (expected ${SCHEMA_VERSION}).`
        );
    }
}

module.exports = { runMigrations, SCHEMA_VERSION };
