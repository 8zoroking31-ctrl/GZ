const { handleGuessMessage } = require("../handlers/guessHandler");

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild) return;
        await handleGuessMessage(client, message);
    },
};
