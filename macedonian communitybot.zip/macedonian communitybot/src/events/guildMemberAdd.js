const { markScoreMemberActive } = require("../services/guessGame");

module.exports = {
    name: "guildMemberAdd",
    async execute(client, member) {
        if (member.user.bot) return;
        markScoreMemberActive(member.guild.id, member.id);
    },
};
