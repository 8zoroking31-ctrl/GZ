const { markScoreMemberLeft } = require("../services/guessGame");

module.exports = {
    name: "guildMemberRemove",
    async execute(client, member) {
        if (member.user.bot) return;
        markScoreMemberLeft(member.guild.id, member.id);
    },
};
