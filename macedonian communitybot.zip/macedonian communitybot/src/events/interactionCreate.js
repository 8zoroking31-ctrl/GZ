const { replyEphemeral } = require("../utils/replies");
const { createNoticeContainer } = require("../utils/components");
const {
    GUESS_CONFIG_MODAL_ID,
    handleGuessConfigModalSubmit,
} = require("../handlers/guessConfigModal");
const {
    handleLeaderboardButton,
    isLeaderboardButton,
} = require("../handlers/guessLeaderboardHandler");

module.exports = {
    name: "interactionCreate",
    async execute(client, interaction) {
        if (interaction.isModalSubmit()) {
            if (interaction.customId === GUESS_CONFIG_MODAL_ID) {
                try {
                    await handleGuessConfigModalSubmit(interaction, client);
                } catch (error) {
                    console.error("[CommunityBot] Guess config modal error:", error.message);
                    try {
                        await replyEphemeral(
                            interaction,
                            createNoticeContainer("Error", "Could not save those settings.")
                        );
                    } catch {
                        // interaction may have expired
                    }
                }
            }
            return;
        }

        if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command?.autocomplete) return;

            try {
                await command.autocomplete(interaction, client);
            } catch (error) {
                console.error(
                    `[CommunityBot] Autocomplete error (${interaction.commandName}):`,
                    error.message
                );
                try {
                    if (!interaction.responded) {
                        await interaction.respond([]);
                    }
                } catch {
                    // interaction already expired
                }
            }
            return;
        }

        if (interaction.isButton()) {
            if (isLeaderboardButton(interaction.customId)) {
                try {
                    await handleLeaderboardButton(interaction);
                } catch (error) {
                    console.error("[CommunityBot] Leaderboard button error:", error.message);
                }
            }
            return;
        }

        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(
                `[CommunityBot] Command error (${interaction.commandName}):`,
                error.message
            );
            try {
                await replyEphemeral(
                    interaction,
                    createNoticeContainer("Error", "Something went wrong running that command.")
                );
            } catch {
                // interaction may have expired
            }
        }
    },
};
