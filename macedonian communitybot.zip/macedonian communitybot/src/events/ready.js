const { ActivityType } = require("discord.js");
const { startGuessScheduler } = require("../services/guessScheduler");
const { restoreRoundTimers } = require("../services/guessRoundTimer");
const { reconcileScoreMembership } = require("../services/guessGame");
const { registerGuildCommands } = require("../services/registerCommands");

module.exports = {
    name: "clientReady",
    once: true,
    async execute(client) {
        console.log(`[CommunityBot] Logged in as ${client.user.tag}`);
        console.log(`[CommunityBot] Serving ${client.guilds.cache.size} guild(s)`);

        const guildId = process.env.GUILD_ID;
        if (guildId) {
            if (!client.guilds.cache.has(guildId)) {
                const joined = [...client.guilds.cache.keys()].join(", ") || "(none)";
                console.warn(
                    `[CommunityBot] GUILD_ID ${guildId} is not a guild this bot is in. Joined: ${joined}`
                );
            } else {
                registerGuildCommands({
                    token: process.env.BOT_TOKEN,
                    clientId: process.env.CLIENT_ID,
                    guildId,
                    clearGlobal: true,
                })
                    .then((count) => {
                        console.log(
                            `[CommunityBot] Synced ${count} slash command(s) to guild ${guildId}`
                        );
                    })
                    .catch((err) => {
                        console.error("[CommunityBot] Failed to sync slash commands:", err.message);
                    });
            }
        } else {
            console.warn("[CommunityBot] GUILD_ID missing — run npm run deploy to register commands.");
        }

        client.user.setPresence({
            activities: [{ name: "Guess the number (1 to 100)", type: ActivityType.Playing }],
            status: "online",
        });

        startGuessScheduler(client);
        restoreRoundTimers(client);

        if (guildId && client.guilds.cache.has(guildId)) {
            reconcileScoreMembership(client, guildId).catch((err) => {
                console.warn("[CommunityBot] Score membership sync failed:", err.message);
            });
        }
    },
};
