require("dotenv").config();

const { Client, GatewayIntentBits } = require("discord.js");
const { getGuildSettings } = require("../src/services/guildSettings");
const { startRound, hasActiveRound, endRound } = require("../src/services/guessGame");

const force = process.argv.includes("--force");

async function main() {
    const token = process.env.BOT_TOKEN;
    const guildId = process.env.GUILD_ID;

    if (!token || !guildId) {
        console.error("[CommunityBot] BOT_TOKEN and GUILD_ID are required in .env");
        process.exit(1);
    }

    console.warn(
        "[CommunityBot] Tip: stop `npm start` before running this script (one bot session per token)."
    );
    console.warn("[CommunityBot] Do not run this while `npm start` is using the same token.\n");

    const client = new Client({
        intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
    });

    client.once("clientReady", async () => {
        try {
            const settings = getGuildSettings(guildId);

            if (!settings?.game_channel_id) {
                console.error("[CommunityBot] No game channel configured. Run /guess-setup in Discord.");
                process.exit(1);
            }

            if (hasActiveRound(guildId)) {
                if (!force) {
                    console.error(
                        "[CommunityBot] A round is already active. Pass --force to replace it."
                    );
                    process.exit(1);
                }
                endRound(guildId);
                console.log("[CommunityBot] Ended previous round.");
            }

            const channel = await client.channels.fetch(settings.game_channel_id);
            if (!channel?.isTextBased()) {
                console.error("[CommunityBot] Game channel is not a text channel.");
                process.exit(1);
            }

            const result = await startRound(client, guildId, channel);
            if (!result.ok) {
                console.error("[CommunityBot] Failed to start round:", result.reason);
                process.exit(1);
            }

            console.log(`[CommunityBot] Round posted in #${channel.name} (message ${result.messageId}).`);
            if (
                process.env.GUESS_TEST_REVEAL_SECRET === "1" ||
                process.env.GUESS_TEST_REVEAL_SECRET === "true"
            ) {
                console.log(`[CommunityBot] Secret number: ${result.secret}`);
            }
        } finally {
            client.destroy();
            process.exit(0);
        }
    });

    await client.login(token);
}

main().catch((err) => {
    console.error("[CommunityBot]", err.message);
    process.exit(1);
});
